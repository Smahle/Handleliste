import ShoppingCartManager from "../components/ShoppingCartManager";

export default function Shop(){
    return (
    <ShoppingCartManager showFullControls={false} />
    );
}