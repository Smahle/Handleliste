export default function NotFound() {
  return (
    <>
      <p>Not found</p>
    </>
  );
}
